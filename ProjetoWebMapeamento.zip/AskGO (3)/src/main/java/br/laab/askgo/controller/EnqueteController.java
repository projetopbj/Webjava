package br.laab.askgo.controller;

public class EnqueteController {

}
