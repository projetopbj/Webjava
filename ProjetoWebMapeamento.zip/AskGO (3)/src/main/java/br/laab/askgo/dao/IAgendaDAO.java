package br.laab.askgo.dao;

import br.laab.askgo.entities.Agenda;

public interface IAgendaDAO extends IDAO<Agenda, Long>{

}
