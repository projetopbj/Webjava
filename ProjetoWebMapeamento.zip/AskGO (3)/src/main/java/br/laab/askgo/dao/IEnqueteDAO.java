package br.laab.askgo.dao;

import br.laab.askgo.entities.Enquete;

public interface IEnqueteDAO extends IDAO<Enquete, Long> {

}
