package br.laab.askgo.dao;

import br.laab.askgo.entities.OpcaoEnquete;

public interface IOpcaoEnqueteDAO extends IDAO<OpcaoEnquete, Long> {

}
