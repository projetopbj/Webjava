package br.laab.askgo.dao.Imp;

import br.laab.askgo.dao.IEnqueteDAO;
import br.laab.askgo.entities.Enquete;

public class EnqueteDAO extends DAO<Enquete, Long> implements IEnqueteDAO{

}
