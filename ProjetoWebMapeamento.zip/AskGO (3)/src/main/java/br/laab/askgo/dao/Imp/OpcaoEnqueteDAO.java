package br.laab.askgo.dao.Imp;

import br.laab.askgo.dao.IOpcaoEnqueteDAO;
import br.laab.askgo.entities.OpcaoEnquete;

public class OpcaoEnqueteDAO extends DAO<OpcaoEnquete, Long> implements IOpcaoEnqueteDAO{

}
