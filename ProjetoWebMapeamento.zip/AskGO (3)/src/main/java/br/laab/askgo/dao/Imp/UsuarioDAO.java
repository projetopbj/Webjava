package br.laab.askgo.dao.Imp;

import br.laab.askgo.dao.IUsuarioDAO;
import br.laab.askgo.entities.Usuario;

public class UsuarioDAO extends DAO<Usuario, Long> implements IUsuarioDAO {
	 
}