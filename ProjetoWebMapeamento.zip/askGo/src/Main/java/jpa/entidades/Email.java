package Main.java.jpa.entidades;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
@SequenceGenerator(sequenceName="email_seq", name="email_id")
public class Email {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator= "email_id")
	private Long id;
	private String nomeEmail;
	
	@OneToOne
	private Usuario usuario;
	
	
	
	
	public Usuario getUsuario() {
		return usuario;
	}
	public void setUsuario(Usuario usuario) {
		this.usuario = usuario;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getNomeEmail() {
		return nomeEmail;
	}
	public void setNomeEmail(String nomeEmail) {
		this.nomeEmail = nomeEmail;
	}
	
	
}
