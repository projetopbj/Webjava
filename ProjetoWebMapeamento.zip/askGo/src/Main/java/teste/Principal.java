package Main.java.teste;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import Main.java.jpa.entidades.Celular;
import Main.java.jpa.entidades.Email;
import Main.java.jpa.entidades.Enquete;
import Main.java.jpa.entidades.Usuario;

public class Principal {
	public static void main(String[] args) {
		EntityManagerFactory fac = Persistence.createEntityManagerFactory("cadastroUsuario");
		EntityManager manager = fac.createEntityManager();
		
		Usuario usuario = new Usuario();
		
		usuario.setNome("Lucas");
		usuario.setCpf("11111111111");
		usuario.setIdade(21);
		
		Email email = new Email();
		
		email.setNomeEmail("pragramadorjava@gmail.com");
		email.setUsuario(usuario);
		
		Celular celular = new Celular();
		
		celular.setNumero("911111111");
		celular.setUsuario(usuario);
		
		usuario.setCelular(celular);
		usuario.setEmail(email);
		
		Enquete enquete = new Enquete();
		enquete.setAssunto("festa java");
		enquete.setTexto("Você foi confidado para uma festa de programadores de java no dia 06/03/2018");
		enquete.setVotos(1);
		enquete.setUsuarios(usuario);
		
		usuario.setEnquete(enquete);
		
		manager.getTransaction().begin();
		manager.persist(usuario);
		manager.getTransaction().commit();
		
		manager.getTransaction().begin();
		manager.persist(celular);
		manager.getTransaction().commit();
		
		manager.getTransaction().begin();
		manager.persist(email);
		manager.getTransaction().commit();
		
		manager.getTransaction().begin();
		manager.persist(enquete);
		manager.getTransaction().commit();
		
	}
}
